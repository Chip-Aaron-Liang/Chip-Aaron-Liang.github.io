---
cssclass: "kanban gridlist noyaml"
tag: "moc"
obsidianUIMode: "preview"
--- `button-homewp`  `button-browsevault`  `button-browsenext` `button-browserefresh` 
%% Begin Waypoint %%
- **[[◾ TableExample]]**
	- [[◾ TableExample]]
	- [[01 - Default Table]]
	- [[02 - PurpleRed]]
	- [[03 - FlatBlue]]
	- [[04 - Latex like]]
	- [[05 - White red rounded]]
	- [[05 - White red]]
	- [[06 - Yellow cab]]
	- [[07 - Center Table]]

%% End Waypoint %%