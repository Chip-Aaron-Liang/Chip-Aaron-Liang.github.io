---
cssclass: "inline-list"
usage: "图片和列表混排"
---

>  这是一个行内列表显示图片的示例，需要在yaml区域声明cssclass

![[obsidian_image.png|inlL|150]]

- 图中是鸡蛋
	- 不，它不是
	- 上面的说法不对
	- 顶楼上
		- 骗回复
- 不是鸭蛋
	- 胡说！
	- 反驳楼上
		- 反驳
		- 支持

![[obsidian_image.png|inlL|200]]
1. 颜色
2. 形状
3. 大小
4. 产地
5. 母鸡品种
6. 价格