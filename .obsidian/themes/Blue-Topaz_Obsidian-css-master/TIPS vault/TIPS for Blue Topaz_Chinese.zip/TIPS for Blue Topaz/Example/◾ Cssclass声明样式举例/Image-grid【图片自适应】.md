---
cssclass: "img-grid"
usage: "图片自适应分布"
---

>  这是一个图片自适应示例，需要在yaml区域声明cssclass

![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]

![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]

![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]