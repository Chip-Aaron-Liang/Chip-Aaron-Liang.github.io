---
updated: 2022-04-23 00:36
created: 2022-04-07 15:08
cssClass: noscroll, fullwidth, noyamal
obsidianUIMode: preview
---
# TIPS


![[00-Tips preface]]

![[Emphasizing and Decorating]]
 
---

![[tags]]

![[Customized Text Box]]

![[Colorized Text]]

![[Colorful Highlight]]

![[Recall and Hidden Text Boxes]]


![[Importent Text]]

![[Pictures in Notes |Pictures in Notes]]

![[Using HTML in Blue Topaz| Using HTML in Blue Topaz]]

![[Pseudo Kanben, ad and callout declaration EN|Pseudo Kanban, Using Admonition and callout]]
![[Kanban|Kanban]]
![[Admonition Split Columns]]
![[More Customized Table Styles]]


