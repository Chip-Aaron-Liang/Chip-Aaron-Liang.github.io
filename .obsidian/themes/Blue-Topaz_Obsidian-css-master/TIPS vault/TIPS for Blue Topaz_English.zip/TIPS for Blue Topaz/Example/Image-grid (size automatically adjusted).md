---
cssclass: img-grid
usage: Image size automaticall adjusted 
---

>  Images in this note will automatically adjust its size accoding with screen width in `Reading` mode, needs `YAML` declaration.

![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]
![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]
![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]![[obsidian_image.png]]