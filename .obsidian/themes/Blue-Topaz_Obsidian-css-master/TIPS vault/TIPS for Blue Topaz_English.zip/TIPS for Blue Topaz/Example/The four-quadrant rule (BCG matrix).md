---
cssclass: matrix
obsidianUIMode: preview
usage: The four-quadrant rule (BCG matrix)
Aliases: BCG Matrix
---

> - This note shows the four-quadrant rule (or the BCG matrix) in Obsidian. In order to show it correctly, a cssclass declaration of `cssclass: matrix` must be in `YAML`

> - The plugin [obsidian-view-mode-by-frontmatter](obsidian://show-plugin?id=obsidian-view-mode-by-frontmatter)  is needed.

##  The four-quadrant rule (BCG matrix)


|                        |                    |
| ---------------------- | ------------------ |
| ![[#Important and Urgent]]       | ![[#Important but not Urgent]]  |
| ![[#Neither Important nor Urgent]] | ![[#Urgent but not Important]] |
|                     |               |


---

## Important and Urgent           

- Works must be completed!        
- Preparation for tomorrow Examination!    
- Have car fixed. 
- Answer Boss phone in 15 minutes.  
        

## Important but not Urgent              

- Preparation for 3 months after driver's test. 
- Keep in shape.     
- Reading more Classic Books        

## Neither Important nor Urgent     

- Dreaming in day      
- Watching Clouds     
        

## Urgent but not Important        
- Friend drop in working       
- Go shopping for pens        



