---
cssclass: noscroll
usage: Hide scrollbar of this note
date updated: 2022-01-27 18:12
updated: 2022-04-06 21:29
---

## List

- aaa
	- aaa
		- 
		- aaa
			- 33333
				- 4444
					- 444
			- 4444 
		- aaa
	- 5555
- 55555
## Order List

1. aaa
   1. aaa
   2. aaa
2. aaa
   1. 3333
   2. aaa
      1. aaa
3. ccc
4. ddd
   1. aaa
   2. bbb

## Rainbow Outliner 

- First layer
	- Second Layer
		- Third Layer
			- Fourth Layer
				- Fifth Layer
					- Sixth Layer
						- Seven Layer
							- Eighth Layer
								- Nineth Layer
								- Nineth Layer
							- Eighth Layer
						- Seven Layer
					- Sixth Layer
				- Fifth Layer
			- Fourth Layer
		- Thirth Layer
	- Second Layer
- First Layer


1. [x] aaa
   1. [ ] 2222
      1. [x] 22222
      2. [ ] 33333
         1. [x] 222
            1. [ ] 22222
               1. [x] 3333
                  1. [ ] 3333
                  2. [ ] ee
                     1. [ ] fsfsfs
                     2. [ ] 44444
         2. [ ] 222
      3. [ ] 333
   2. [ ] 333
2. [ ] 3333
- 333
	- asdasd
	- 44
		- 
 - ddd
 - ddd



## Checkboxes

- [x]  11
- [>]  222
	- [ ] 333
		- [ ] 333
		- [x] 3333
			- [x] 4444
			- [ ] 4444
- [<] 11
- [!] 11
- [<] abcdefg
	- [+] add
- [ ] abcdefg
- [!] ideas
- [?] questions   
- [x] checked
- [ ] hollow
- [-] removed


- list1
  333 ^c9b22a
	- list2
	  3333
	- list2-1
	- list2-2 ^c9b22b
		- list3
		- list3-1
		- list3-2 ^c9b22c
			- list4 ^c9b22d
				- list5 
					- list6 ^c9b22f
						- list



- [ ] 11111
	- [x] 222222 ✅ 2022-03-30
		- [ ] 333333
		      33333
			- [ ] 333
			- [ ] 333
		- [ ] 33333
	- [ ] 2222
- [ ] 222222
- [ ] 333333

