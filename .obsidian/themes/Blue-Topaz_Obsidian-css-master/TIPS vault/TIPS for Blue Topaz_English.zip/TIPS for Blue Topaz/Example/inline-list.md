---
cssclass: inline-list
usage: Mixed images and lists 
---

>![[Yaml declaration]]

![[obsidian_image.png|inlL|150]]

- This is an egg!
	- No, it is NOT an egg.
	- Above said is wrong.
	- Let me in!
		- Lure for replay.
- Not a duck egg.
	- Bullshits!
	- Object!
		- NO!
		- Yes!

![[obsidian_image.png|inlL|200]]
1. Color
2. Shape
3. Size
4. Original from 
5. Kinds of hen
6. Price