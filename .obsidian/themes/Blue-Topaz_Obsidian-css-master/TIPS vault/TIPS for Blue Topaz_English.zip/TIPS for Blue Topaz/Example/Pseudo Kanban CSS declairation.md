---
cssclass: kanban 
usage: Pseudo-Kanban, four collums unordered lists
updated: 2022-03-14 20:31
---
 ```ad-tip
 This is a demo of pseudo-kanban ![[Yaml declaration EN]]
```

- [ ] 紫色鸡蛋
	- [ ] Obsidian其实是紫色鸡蛋
	- [ ] 不断灌输这个，他们就当真了
	- [ ] 不能告诉他们真相
- [ ] 其实那是鸭蛋
	- [ ] 事实太过残酷
	- [ ] 不忍直视
- [ ] 说笑的，那真是鸡蛋
	- [ ] 不信我也没办法
	- [ ] 信鸡蛋，得永生
- 不加勾选框也可以
	- 不影响是不是鸡蛋的问题
	- 但是有序列表不可以
- 无序列表
	- 111
	- 2222
- 无序列表
	1.  222
	2. 344
- 无序列表


---
Below is the contents of this note:

````
---
cssclass: kanban 
usage: Pseudo-Kanban, four collums unordered lists
updated: 2022-03-14 20:31
---
 ```ad-tip
 This is a demo of pseudo-kanban ![[Yaml declaration EN]]
```

- [ ] 紫色鸡蛋
	- [ ] Obsidian其实是紫色鸡蛋
	- [ ] 不断灌输这个，他们就当真了
	- [ ] 不能告诉他们真相
- [ ] 其实那是鸭蛋
	- [ ] 事实太过残酷
	- [ ] 不忍直视
- [ ] 说笑的，那真是鸡蛋
	- [ ] 不信我也没办法
	- [ ] 信鸡蛋，得永生
- 不加勾选框也可以
	- 不影响是不是鸡蛋的问题
	- 但是有序列表不可以
- 无序列表
	- 111
	- 2222
- 无序列表
	1.  222
	2. 344
- 无序列表
````