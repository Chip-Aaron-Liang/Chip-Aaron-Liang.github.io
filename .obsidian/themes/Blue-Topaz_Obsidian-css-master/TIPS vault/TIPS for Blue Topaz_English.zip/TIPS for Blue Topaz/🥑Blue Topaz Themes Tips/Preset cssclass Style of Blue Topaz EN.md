---
obsidianUIMode: preview
---

## Preset cssclass Style of Blue Topaz


| cssclass    |role|
| ----------- | ------------------------------------------------------------------ |
| code-wrap   | code-block-auto-wrap                                               |
| img-grid    | image adaptive distribution                                        |
| inline-list | images and lists mixed                                             |
| kanban      | pseudo-kanban style, unordered list of four columns                |
| fullwidth   | reduce column width on, control the full width of the page display |
| noscroll    | hide the current page scrollbar                                    |
| matrix      | four-quadrant table style                                          |
| cards       | rendering-dataview-tables-to-cards-view                            |
| cards       | rendering-dataview-tables-to-cards-view                            |
| noyaml      |preview state does not show the frontmatter area|



```