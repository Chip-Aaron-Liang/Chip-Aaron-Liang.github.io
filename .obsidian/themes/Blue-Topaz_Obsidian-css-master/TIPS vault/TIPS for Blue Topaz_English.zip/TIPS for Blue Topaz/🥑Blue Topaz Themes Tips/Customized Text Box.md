## Customized Text Box
### Text in Colorful Background
*Adopted partial codes from **Notation** theme @deathau*

```ad-todo

Put：==*note-ColorName-bg*==  or ==*note-ColorName-background*== in your text, that is all😊，choise whatever you prefer. Where the **ColorName** can be:

Orange, yellow, green, blue, purple, pink, red, gray, and brown.

```

`````ad-example
title: Take **`orange`** as an example:

If your put code block as below in ==***Source Mode***==

````md
```note-orange-bg
text
```
````
Then in ==***Live Preview***== and ==***Reading***== mode, it should looking like below

```note-orange-bg
text
```
`````

## Here comes the other **==Examples==**

```note-yellow-bg
text
```

```note-green-bg
text
```

```note-blue-bg
text
```

```note-purple-bg
text
```

```note-pink-bg
text
```

```note-red-bg
text
```

```note-gray-bg
text
```

```note-brown-bg
text
```
