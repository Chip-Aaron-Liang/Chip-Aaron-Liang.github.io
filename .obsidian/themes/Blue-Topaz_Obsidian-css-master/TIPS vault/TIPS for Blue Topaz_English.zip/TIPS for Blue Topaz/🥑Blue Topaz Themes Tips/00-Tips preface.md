Translator: @心随风动-灵魂如风

```ad-col2
This is a `Demo Vault` of `Blue Topaz Theme` which you are currently in using the right one of **Obsidian Themes**, you can always get the latest updates of the vault from the **Obsidian Community Themes** and/or the [**Link Here**](https://github.com/cumany/Blue-topaz-examples)  


Here shows the most attractive features of `Bule Topaz` and how to make that happens in your Obsidian notes. Hope you will enjoy and like it.


`Style Setting` and `enhanced Admonition` come with the `Blue Topaz`, you can find certain custom settings there and easily to fine tune the `Blue Topaz` to your own tasts, also, you will probably find the `enhanced Admonition` Plugin's features are more delighted.

You may also find some other Obsidian Plugins come with this theme, which help the theme works well.



It is difficult to guess how widely will this theme spread out, so if you happen to  know well the `QQ` 🐧, then you may find us at **908688452**.

You can also find us at github 😊

Finally, thanks to all fellows in the community of `Topaz`, without you, there will be no `Blue Topaz` theme.

This theme, is dedicated to you all. Thanks for all of your loves to this theme.
```