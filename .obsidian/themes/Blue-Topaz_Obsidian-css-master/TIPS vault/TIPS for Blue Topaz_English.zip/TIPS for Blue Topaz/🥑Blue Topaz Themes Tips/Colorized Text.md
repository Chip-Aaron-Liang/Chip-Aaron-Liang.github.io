### Colorized Text

```ad-todo

Put：
==*note-ColorName*==   

in your text, that is all😊. Where the **ColorName** can be:

Orange, yellow, green, blue, purple, pink, red, gray, and brown.
```

In ==***Live Preview***== and ==***Reading***== mode, it should looking like below (Take orange as an example):

````md
```note-orange
This text color is orange.
```

It shows below:
````

```ad-example
title: Example of Orange Color of Text

```note-orange
This text color is orange.
```


Here comes the others **==Examples==**

````ad-example
title: Example of Colorized Texts

```note-orange
This text color is orange.
```
```note-yellow
This text color is yellow.
```
```note-green
This text color is green.
```
```note-blue
This text color is blue.
```
```note-purple
This text color is purple.
```
```note-pink
This text color is pink.
```
```note-red
This text color is red.
```
```note-gray
This text color is gray.
```

```note-brown
This text color is brown.
```
````
