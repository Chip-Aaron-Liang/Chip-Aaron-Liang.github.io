## More Customized Styles
As mentioned, this Demo Vault incorporated more customized styles in `Style Settings`,  here comes more examples.


###  Example for **==Quote Block==**
> Obsidian实体是紫色鸡蛋Obsidian实体是紫色鸡蛋Obsidian实体是紫色鸡Obsidian实体是紫色鸡蛋Obsidian实体是紫色鸡蛋Obsidian,实体是紫色鸡蛋Obsidian实体是紫色鸡蛋5555
> ssss
> 5555

> 真的，不骗人。


### Example for **==Lists==**
[[Sorts of lists, Checkboxes, Rainbow Outliners and lists EN]]

### Example for **==Admonition Split Columns==**
[[Admonition Split Columns]]
### Example for **==The for-quadrant rule (BCG matrix)==**
[[The four-quadrant rule (BCG matrix)]]
### Example for **==Set fixed height of Embedded Notes==**
>Enable `To fix height of embedded content` in `Style settings` 2.3.6
![[Admonition Split Columns]]
### Example for **==Customized Table Styles==**
- Customized table styles are not incorporated in the theme. Use `TableStyles.css` to enable it. [[Customized Table Styles| Click Here for more examples]]
- To disable auto-wrap in all tables, enable it with `Style settings`, 2.3.8
- Dataview table had been optimized in the **Blue Topaz** with `Style settings`,  3.6. It makes choices to have the dataview table more neat and has a fixed width of the first column
### Styles of Callout in Blue Topaz
[[Callout Styles Show-off and Use]]
