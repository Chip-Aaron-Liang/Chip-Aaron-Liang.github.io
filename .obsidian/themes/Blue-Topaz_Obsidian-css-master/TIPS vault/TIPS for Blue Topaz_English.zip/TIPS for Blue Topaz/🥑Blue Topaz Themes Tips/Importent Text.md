#### Important Text

You may emphasize your important text using codes below:

````
```note-imp
This is important!
```
````

It will show-up as:

```ad-example
title: Example of Important Text

```note-imp
This is important!
```

---

```ad-tips
Please keep in mind, all these enchanced admonition features are only to make your note more colorful, more personal, and more enjoyable.
```